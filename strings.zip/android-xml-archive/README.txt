Loco xml export: Android string resources
Project: Android
Release: Working copy
Exported at: Thu, 20 May 2021 10:21:33 +0800
Exported by: min li