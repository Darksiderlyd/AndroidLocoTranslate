Loco xml export: Android string resources
Project: Android
Release: Working copy
Exported at: Thu, 27 May 2021 11:06:07 +0800
Exported by: min li