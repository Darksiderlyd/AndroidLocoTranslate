Loco xml export: Android string resources
Project: Android
Release: Working copy
Exported at: Tue, 25 Jan 2022 16:50:16 +0800
Exported by: min li